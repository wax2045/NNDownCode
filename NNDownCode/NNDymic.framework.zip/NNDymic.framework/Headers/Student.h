//
//  Student.h
//  NNDymic
//
//  Created by FUWANG on 2018/3/1.
//  Copyright © 2018年 Shenzhen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject
- (void)eat;
- (void)sleep;
@end
